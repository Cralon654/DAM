const formulario = document.querySelector("form");
ocultar = false;
function crearTarjeta() {
    const titulo = document.getElementById("titulo").value;
    const imagen = document.getElementById("imagen");
    const precio = document.getElementById("precio").value;
    const descripcion = document.getElementById("descripcion").value;

    if (!titulo || !imagen.files[0] || !precio) {
        alert("Por favor, completa todos los campos.");
        return;
    }

    const imagenURL = URL.createObjectURL(imagen.files[0]);

    // Crear elementos de la tarjeta
    const tarjeta = document.createElement("div");
    tarjeta.classList.add("tarjeta");

    const img = document.createElement("img");
    img.src = imagenURL;
    img.alt = titulo;

    const h3 = document.createElement("h3");
    h3.textContent = titulo;

    const p = document.createElement("p");
    p.textContent = `${precio}$`;

    const pdescripcion = document.createElement("p");
    pdescripcion.textContent = `${descripcion}`;

    // Crear botón de comprar
    const botonComprar = document.createElement("p");
    botonComprar.classList.add("p-boton");
    botonComprar.textContent = "Comprar";

    // Acción al hacer clic en el botón
    botonComprar.addEventListener("click", () => {
        const confirmar = confirm(`¿Deseas comprar "${titulo}" por ${precio} $?`);
        if (confirmar) {
            alert(`¡Gracias por tu compra de "${titulo}"!`);
            setTimeout(() => {
                
                location.reload();
            }, 2000);
        } else {
            alert("Compra cancelada.");
        }
    });

    // Agregar al DOM
    tarjeta.appendChild(img);
    tarjeta.appendChild(h3);
    tarjeta.appendChild(p);
    tarjeta.appendChild(pdescripcion);
    tarjeta.appendChild(botonComprar);

    document.getElementById("tarjetas").appendChild(tarjeta);

    // Limpiar formulario
    formulario.reset();
}

function ocultarFormulario() {
    boton = document.getElementById("p-boton")
    if (!ocultar) {
        formulario.classList.add("oculto");
        boton.textContent = "Ver más"
        ocultar = true;
    } else {
        formulario.classList.remove("oculto");
        boton.textContent = "Ocultar formulario"

        ocultar = false;
    }

}